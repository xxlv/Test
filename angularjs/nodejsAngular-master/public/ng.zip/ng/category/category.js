angular.module('SharendaApp.Category',[])
.config(['$routeProvider',function($routeProvider) {
	$routeProvider
	.when('/category',{
		controller: 'CategoryController',
		templateUrl: BASE_URL+'/ng/category/category.tpl.html'
	});
}])
.controller('CategoryController',['$scope','CategoryService','AlertService',function($scope,CategoryService,AlertService) {
	$scope.category = {};
	$scope.editCategory = {};
	$scope.$emit('createCategory','res');
	$scope.addCategory = function(data){
		data.duration = data.duration[0];
		if(data.name != null && data.color != null){
			$('body').addClass('disable-page');
			CategoryService.createCategory(data,function(res) {
				$('body').removeClass('disable-page');
				if(res.__all__.status){
					AlertService.success(res.__all__.message);
				}else if(!res.__all__.status){
					AlertService.error(res.errors);
				}
				$('#CategoryModel').modal('hide');
				$scope.category = {};
				$scope.$emit('createCategory',res);
			});
		}
	};
	$scope.deleteCategory = function(data){
		$('body').addClass('disable-page');
		CategoryService.deleteCategory(data.id,function(res) {
			$('body').removeClass('disable-page');
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
			$scope.$emit('createCategory',res);
		});
	};
	$scope.editCate = function(data){
		$scope.editCategory = data;
		$scope.editCategory.duration = parseInt(data.duration);
	};
	$scope.UpdateCategory = function(data){
		data.duration = data.duration[0];
		$('body').addClass('disable-page');
		CategoryService.updateCategory(data,function(res) {
			$('body').removeClass('disable-page');
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
				$scope.editCategory = {};
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
			$('#UpdateCategoryModel').modal('hide');
			$scope.$emit('createCategory',res);
		});
	};

	timefunction = function(num,state){
		options = [];
		start = 0.15;
		end = 24;
		for(var i = start; i < end; i+=0.15) {
			time = i.toFixed(2);
			min = (time%1).toFixed(2);
			if(min == 0.60) {
				i+= 0.40;
				val = i.toFixed(2);
				if(parseFloat(val) < 10){
					op = float2int(val)+":"+val.split(".")[1];
					duration = parseInt(60*val.split(".")[0])+parseInt(val.split(".")[1]);
					options.push({value:duration,text:op});
				}else{
					op = float2int(val)+":"+val.split(".")[1];
					duration = parseInt(60*val.split(".")[0])+parseInt(val.split(".")[1]);
					options.push({value:duration,text:op});
				}
				continue;
			};
			if(parseFloat(time) < 10){
				op = float2int(time)+":"+time.split(".")[1];
				duration = parseInt(60*time.split(".")[0])+parseInt(time.split(".")[1]);
				options.push({value:duration,text:op});
			}else{
				op = float2int(time)+":"+time.split(".")[1];
				duration = parseInt(60*time.split(".")[0])+parseInt(time.split(".")[1]);
				options.push({value:duration,text:op});
			}
		}
		options.pop();
		return options;
	};
	float2int = function(value) {
		return value | 0;
	};
	$scope.durationOptions = timefunction(0,0);
	$scope.durationConfig = {
		valueField: 'value',
		labelField: 'text',
		sort: false,
		sortField: [],
		placeholder: 'heure',
		maxItems: 1,	
	};
}]);