angular.module('SharendaApp.Contact',[])
.config(['$routeProvider',function($routeProvider) {
	$routeProvider
	.when('/contacts',{
		controller: 'ContactController',
		templateUrl: BASE_URL+'/ng/contact/contact.tpl.html'
	});
}])
.directive('dobpickerdate',function() {
	return {
		type: 'A',
		link: function(scope,element,attrs) {
			$(element).datepicker({
				dateFormat:'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				yearRange: "-100:+0"
			});
		}
	};
})
.controller('ContactController',['$scope','ContactService','EventService','AlertService',function($scope,ContactService,EventService,AlertService) {
	$scope.contact = {};
	$scope.name='';
	$scope.contacts= [];
	$scope.viewcontact = {};
	$scope.events = [];
	$scope.checkedButton = false;
	$scope.genderOptions = [];
	$scope.genderOptions.push(
			{label:'Masculin',value:'male'},
			{label:'Féminin',value:'female'}
		);
	ContactService.getContact(function(data) {
		$scope.contacts = data;
		if(data.length > 0) {
			$scope.viewcontact = $scope.contacts[0];
		}
	});
	EventService.getEvent(function(data) {
		$scope.events = data.events;
	});
	$scope.saveContact = function(data)  {
		if($scope.addnew.$valid){
			$('body').addClass('disable-page');
			ContactService.createContact(data,function(res) {
				$scope.contact={};
				ContactService.getContact(function(data) {
					$scope.contacts = data;
					$('.new-contact').popover('hide');
					$('body').removeClass('disable-page');
				});
				AlertService.success(res.__all__.message);
			});
		}
	};
	$scope.updateContact = function(data)  {
		if($scope.updatecontact.$valid){
			ContactService.updateContact(data,function(res) {
				ContactService.getContact(function(data) {
					$scope.contacts = data;
				});
				AlertService.success(res.__all__.message);
			});
		}
	};
	var contactViewHandler =function(data){
		angular.forEach($scope.contacts,function(value) {
			value.state = false;
		});
		data['state']=data['state'] ? false : true;
		$scope.viewcontact  = data;
		
	};	
	$scope.onViewContact = contactViewHandler;
	$scope.deleteContact = function(data){
		ContactService.deleteContact(data.id,function(res) {
			contacts=[];
			angular.forEach($scope.contacts,function(value,key){
				if(data.id!=value.id){
					contacts.push(value);
				}
			});
			$scope.contacts=contacts;
			$('.pull-right').popover('hide');
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
		});
	};
	$scope.deleteEvent = function(data){
		EventService.deleteEvent(data.id,function(res) {
			events=[];
			angular.forEach($scope.events,function(value,key){
				if(data.id!=value.id){
					events.push(value);
				}
			});
			$scope.events=events;
		});
	};
	$scope.setCancelled = function(data){
		EventService.changeStatus(data.id,'cancelled_by_professionnel',function(res) {
			data.status='cancelled_by_professionnel';
			$('.appointment-table').popover('hide');
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
		});
	};
	$scope.nameChange = function(data){
		$scope.name=data;
	};
}]);