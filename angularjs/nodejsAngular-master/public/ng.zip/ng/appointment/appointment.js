angular.module('SharendaApp.Appointment',[])
.config(['$routeProvider',function($routeProvider) {
	$routeProvider
	.when('/appointment',{
		controller: 'AppointmentController',
		templateUrl: BASE_URL+'/ng/appointment/appointment.tpl.html'
	});
}])
.controller('AppointmentController',['$scope','EventService','AlertService',"UserService","ContactService",function($scope,EventService,AlertService,UserService,ContactService) {

	$scope.userPurpose = {}; //naveen
	$scope.Contacts = {}; //naveen
	$scope.appointment = {}; //naveen
	$scope.questions = {};
	$scope.eventUser = function(e){
		$scope.appointment = e;
		$scope.appointment.duration = parseInt(e.duration);
		$scope.appointment.start = moment(e.start_datetime.split(" ")[0]).format("DD/MM/YYYY");
		$scope.appointment.time = e.start_datetime.split(" ")[1].replace(":",".").split(":")[0];
		questions =e.question;
		$scope.appointment.question = [];
		angular.forEach(questions,function(question) {
			angular.forEach($scope.questions,function(row){
				if(question.question_id == row.id && row.type == "list"){
					angular.forEach(row.option,function(option){
						if(option.option == question.answer){
							$scope.appointment.question[question.question_id] = option.id;
						}
					});
				}else if(question.question_id == row.id){
					$scope.appointment.question[question.question_id] = question.answer;
				}
			});
		});
		$scope.event.$submitted = false;
	}; //naveen
	$scope.userEvent = function(e){
		id = e.id;
		if(e.start == '01/01/1970'){
			e.start = $scope.appointment.start;
			$scope.$apply();
		}
		data = e;
		data.client_id = e.client_id[0];
		data.category_id = e.category_id[0];
		data.time = e.time[0];
		EventService.updateUserEvent(id,data,function(res){
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
				$('#updateeventModal').modal('hide');
				EventService.getPageEvent(0,function(data) {
					$scope.events = data.events;
					totalItems = data.total;
					var pages= Math.ceil(totalItems/10);
					$scope.numbers = [];
					for(var i=1;i<=pages;i++){
						$scope.numbers.push(i);
					}
				});
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
		});
	}; //naveen
	$scope.statusOptions = [];
	$scope.statusOptions.push(
		{label:$scope.LOCALE.status_pending,value:'pending'},
		{label:$scope.LOCALE.status_approved,value:'approved'},
		{label:$scope.LOCALE.status_closed,value:'closed'},
		{label:$scope.LOCALE.status_cancelled_by_professional,value:'cancelled_by_professionnel'},
		{label:$scope.LOCALE.status_cancelled_by_client,value:'cancelled_by_client'}
		);	
	$scope.statusConfig = {
		valueField: 'value',
		labelField: 'label',
		placeholder: $scope.LOCALE.appointment_filter_by_status,
		sortField: 'text',
		maxItems: 1,
	};
	$scope.categoryConfig = {
		valueField: 'name',
		labelField: 'name',
		placeholder: $scope.LOCALE.appointment_filter_by_category,
		sortField: 'text',
		maxItems: 1,
	};
	$scope.status='';
	$scope.category='';
	$scope.events = [];
	var totalItems =0;
	$scope.numbers = [];
	$scope.currentpage = 1;
	$scope.$watch('user',function() {
		if($scope.user.role == 'professionnel'){
			EventService.getPageEvent(0,function(data) {
				$scope.events = data.events;
				totalItems = data.total;
				var pages= Math.ceil(totalItems/10);
				for(var i=1;i<=pages;i++){
					$scope.numbers.push(i);
				}
			});
		}else if($scope.user.role == 'client'){
			EventService.getClientEvent(function(data) {
				$scope.events = data.events;
				totalItems = data.total;
				var pages= Math.ceil(totalItems/10);
				for(var i=1;i<=pages;i++){
					$scope.numbers.push(i);
				}
			});
		}
	});
	$scope.getPageEvent = function(data){
		if($scope.user.role != 'client'){
			$scope.currentpage=data;
			EventService.getPageEvent((data-1),function(res) {
				$scope.events = res.events;
				totalItems = res.total;
				var pages = Math.ceil(totalItems/10);
				$scope.numbers=[];
				for(var i=1;i<=pages;i++){
					$scope.numbers.push(i);
				}
			});
		}else if($scope.user.role == 'client'){
			$scope.currentpage=data;
			EventService.getClientPageEvent((data-1),function(res) {
				$scope.events = res.events;
				totalItems = res.total;
				var pages = Math.ceil(totalItems/10);
				$scope.numbers=[];
				for(var i=1;i<=pages;i++){
					$scope.numbers.push(i);
				}
			});
		}
	};
	$scope.deleteEvent = function(data){
		EventService.deleteEvent(data.id,function(res) {
			events=[];
			angular.forEach($scope.events,function(value,key){
				if(data.id!=value.id){
					events.push(value);
				}
			});
			$scope.events=events;
		});
	};
	$scope.setApproved = function(data){		
		EventService.changeStatus(data.id,'approved',function(res) {
			data.status='approved';
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
		});
	};
	$scope.setCancelled = function(data){
		if($scope.user.role=='professionnel'){
			EventService.changeStatus(data.id,'cancelled_by_professionnel',function(res) {
				data.status='cancelled_by_professionnel';
				if(res.__all__.status){
					AlertService.success(res.__all__.message);
				}else if(!res.__all__.status){
					AlertService.error(res.errors);
				}
			});
		}else if($scope.user.role=='client'){
			EventService.changeClientStatus(data.id,'cancelled_by_client',function(res) {
				data.status='cancelled_by_client';
				if(res.__all__.status){
					AlertService.success(res.__all__.message);
				}else if(!res.__all__.status){
					AlertService.error(res.errors);
				}
			});
		}
	};
	$scope.statusChange = function(data){
		$scope.status=data;
	};
	$scope.categoryChange = function(data){
		$scope.category=data;
	};
	$scope.changeEventCategory = function(id){
		if($scope.event.$submitted){
			angular.forEach($scope.user.categories,function(value,key){
				if(value.id == id[0]){
					$scope.appointment.duration = parseInt(value.duration);
				}
			});
		}else{
			$scope.event.$submitted = true;
		}
	};
	timefunction = function(num,state){
		options = [];
		start = 0;
		end = 24;
		for(var i = start; i < end; i+=0.15) {
			time = i.toFixed(2);
			min = (time%1).toFixed(2);
			if(min == 0.60) {
				i+= 0.40;
				val = i.toFixed(2);
				if(parseFloat(val) < 10){
					op = float2int(val)+":"+val.split(".")[1];
					options.push({value:'0'+val,text:op});
				}else{
					op = float2int(val)+":"+val.split(".")[1];
					options.push({value:val,text:op});
				}
				continue;
			};
			if(parseFloat(time) < 10){
				op = float2int(time)+":"+time.split(".")[1];
				options.push({value:'0'+time,text:op});
			}else{
				op = float2int(time)+":"+time.split(".")[1];
				options.push({value:time,text:op});
			}
		}
		options.pop();
		return options;
	};
	float2int = function(value) {
		return value | 0;
	};
	$scope.timeOptions = timefunction(0,0);
	$scope.timeConfig = {
		valueField: 'value',
		labelField: 'text',
		sort: false,
		sortField: [],
		placeholder: 'heure',
		maxItems: 1,	
	};
	$scope.$watch('user',function() {
		if($scope.user.role == 'professionnel'){
			UserService.getInfo(function(data) {
				$scope.questions = data.questions;
				$scope.userPurpose = data.purposes.purpose;
			});
			ContactService.getContact(function(data) {
				$scope.Contacts = data;
			});
		}
	});
	$scope.updateCategoryConfig = {
		valueField: 'id',
		labelField: 'name',
		maxItems: 1,
		placeholder: 'Choisir une catégorie',
	};

}]);