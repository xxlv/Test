angular.module('SharendaApp.Settings',[])
.config(['$routeProvider',function($routeProvider) {
	$routeProvider
	.when('/settings',{
		controller: 'SettingsController',
		templateUrl: BASE_URL+'/ng/settings/settings.tpl.html'
	});
}])
.directive('pickerdate',function() {
	return {
		type: 'A',
		link: function(scope,element,attrs) {
			$.datepicker.setDefaults($.datepicker.regional['fr']);
			$(element).datepicker({
				dateFormat:'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				yearRange: "-100:+0"
			});
			$(element).datepicker( "option",$.datepicker.regional[ 'fr' ] );
		}
	};
})
.directive('offlinedatestart',function() {
	return {
		type: 'A',
		link: function(scope,element,attrs) {
			$.datepicker.setDefaults($.datepicker.regional['fr']);
			$(element).datepicker({
				minDate: 0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				yearRange: "-0:+5",
				onSelect: function(selected){
					scope.offline.start_date = selected;
                                      		$("#enddate").datepicker("option","minDate",selected);
                               		}

			});
		}
	};
})
.directive('offlinedateend',function() {
	return {
		type: 'A',
		link: function(scope,element,attrs) {
			$.datepicker.setDefaults($.datepicker.regional['fr']);
			$(element).datepicker({
				minDate:0,
				dateFormat: 'dd/mm/yy',
				changeMonth: true,
				changeYear: true,
				yearRange: "-0:+5",
				onSelect: function(selected){
					scope.offline.end_date = selected;
                                      		$("#startdate").datepicker("option","maxDate",selected);
                               		}
			});
		}
	};
})
.directive('switch',function() {
	return {
		type: 'A',
		link: function(scope,element,attrs) {
			$(element).switchButton({
				on_label: "I",
				off_label: "0",
				width: 60,
				height: 25,
				button_width: 25,
				checked: scope.schedules[scope.schedule.id].status,
				on_callback: function() {
					scope.schedules[scope.schedule.id].status = 1;
				},
				off_callback: function() {
					scope.schedules[scope.schedule.id].status = 0;
				}
			});	
		}
	};
})
.factory('ChannelService',function($http) {
	channelService = {};
	channelService.getChannels = function(callback) {
		$http.get(window.BASE_URL+'professionnel/channel').success(function(res) {
			callback(res);
		});
	};
	channelService.deleteChannel = function(id,callback){
		$http.get(window.BASE_URL+'professionnel/channel/create?delete=1&channel='+id).success(function(res) {
			callback(res);
		});
	};
	channelService.createChannel = function(id,callback){
		data=[{add:1,channel:id}];
		$http.post(window.BASE_URL+'professionnel/channel',data[0]).success(function(res) {
			callback(res);
		});
	};
	return channelService;
})
.factory('ScheduleService',function($http) {
	scheduleService = {};
	scheduleService.getSchedule = function(callback) {
		$http.get(window.BASE_URL+'professionnel/schedule').success(function(res) {
			callback(res);
		});
	};
	scheduleService.createSchedule = function(callback) {
		$http.get(window.BASE_URL+'professionnel/schedule/create').success(function(res) {
			callback(res);
		});
	};
	scheduleService.updateScheduleInfo = function(data,callback) {
		$http.post(window.BASE_URL+'professionnel/schedule',data).success(function(res) {
			callback(res);
		});
	};
	return scheduleService;
})
.factory('OfflineService',function($http) {
	offlineService = {};
	offlineService.getOffline = function(callback) {
		$http.get(window.BASE_URL+'professionnel/offline').success(function(res) {
			callback(res);
		});
	};
	offlineService.updateOffline = function(id,data,callback) {
		$http.put(window.BASE_URL+'professionnel/offline/'+id,data).success(function(res) {
			callback(res);
		});
	};
	return offlineService;
})
.factory('LatLongService',function($http){
	latlongService = {};
	latlongService.getLatLong = function(address,callback){
		$http.get("http://maps.googleapis.com/maps/api/geocode/json?address="+address).success(function(data) {
			callback(data);
		});
	};
	return latlongService;
})
.controller('SettingsController',['$scope','$upload','ProfileService','ScheduleService','ChannelService','AlertService','OfflineService','LatLongService',function($scope,$upload,ProfileService,ScheduleService,ChannelService,AlertService,OfflineService,LatLongService) {
	$scope.parentTab = 'configure';
	$scope.innerTab = 'account';
	$scope.genderOptions = [];
	$scope.timezoneOptions = [];
	$scope.profession = {};
	$scope.userProf = {};
	$scope.specialty = [];
	$scope.files = [];
	$scope.startTime = [];
	$scope.endTime = [];
	$scope.schedules = [];
	$scope.offline = {};
	$scope.offlineOptions = [];
	$scope.offlineOptions.push(
			{label:'Activer',value:"1"},
			{label:'Désactiver',value:"0"}
		);
	$scope.channels = [];
	$scope.genderOptions.push(
			{label:'Masculin',value:'male'},
			{label:'Féminin',value:'female'}
		);
	$scope.updateTab = function(data){
		$scope.parentTab = data;
	};
	$scope.updateTabInner = function(data){
		$scope.innerTab=data;
	};
	$scope.deleteChannel = function(data){
		channelService.deleteChannel(data,function(res) {
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
				ChannelService.getChannels(function(data) {
					$scope.channels = data.channel;
				});
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
		});
	};
	$scope.createChannel = function(data){
		channelService.createChannel(data,function(res) {
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
				ChannelService.getChannels(function(data) {
					$scope.channels = data.channel;
				});
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
		});
	};
	$scope.updateUser = function(data){
		var address = data.address+', '+data.zipcode+' '+data.city;
		LatLongService.getLatLong(address,function(latlong){
			data.latitude = latlong.results[0].geometry.location.lat;
			data.longitude = latlong.results[0].geometry.location.lng;
			ProfileService.updateProfile(data,function(res){
				if(res.__all__.status){
					AlertService.success(res.__all__.message);
				}else if(!res.__all__.status){
					AlertService.error(res.errors);
				}
			});
		});
	};
	$scope.$watch('user',function() {
		if($scope.user.role == 'professionnel'){
			OfflineService.getOffline(function(data){
				$scope.offline = data.offline;
			});
			ChannelService.getChannels(function(data) {
				$scope.channels = data.channel;
			});
			ScheduleService.getSchedule(function(data) {
				if(data.schedules.length==0){
					ScheduleService.createSchedule(function(response) {
						$scope.schedules = response.schedules;
					});
				}else{
					$scope.schedules = data.schedules;
				}
				angular.forEach($scope.schedules,function(value,key){
					value.id = parseInt(value.id);
					key = parseInt(key);
					timeOptions = TimeGeneration(0,0);
					$scope.startTime[value.id] = timeOptions; 
					$scope.endTime[value.id] = timeOptions;
				});
			});
			ProfileService.getUserProf(function(data) {
				$scope.userProf=data.details;
				ProfileService.getProf(function(data) {
					$scope.profession=data.profession;
					changeProfessionHandler($scope.userProf);
				});
			});
		}
	});
	$scope.updateOffline = function(data){
		OfflineService.updateOffline(data.id,data,function(res){
			if(res.__all__.status){
				AlertService.success(res.__all__.message);
			}else if(!res.__all__.status){
				AlertService.error(res.errors);
			}
		});
	};
	$scope.updateSchedule = function(data){
		if($scope.scheduleup.$valid){
			scheduleService.updateScheduleInfo(data,function(res){
				if(res.__all__.status){
					AlertService.success(res.__all__.message);
				}else if(!res.__all__.status){
					AlertService.error(res.errors);
				}
			});
		}
	};
	$scope.updateProfileProf = function(data){
		file = $scope.files[0];
		$scope.upload = $upload.upload({
		        url: window.BASE_URL+'professionnel/profile',
		        method: 'POST',
		        data: data,
		        file: file,
		}).progress(function(evt) {		
		}).success(function(data, status, headers, config) {
			if(data.__all__.status){
				AlertService.success(data.__all__.message);
			}else if(!data.__all__.status){
				AlertService.error(data.errors);
			}
		});
	};
	$scope.imageHandler =function($files){
		$scope.files = $files;
	};
	$scope.imageHandlerOne =function($files,data){
		field =[];
		field.push({field:data});
		$scope.upload = $upload.upload({
		        url: window.BASE_URL+'professionnel/profile/image',
		        method: 'POST',
		        data: field[0],
		        file: $files[0],
		}).error(function(data,status,headers,config){
			AlertService.error(data.errors.image);
		});
	};
	changeProfessionHandler = function(data){
		specialty=[];
		angular.forEach($scope.profession,function(value,key){
			if(data.professionnel==value.id){ 
				angular.forEach(value.specialty,function(item){
					specialty.push(item);
				});
			}
		});
		$scope.specialty = specialty;
	};	
	$scope.changeProfession = changeProfessionHandler;
	$scope.changeStartTime = function(id,data){
		$scope.endTime[id] = TimeGeneration(data,1); 
	};
	$scope.changeEndTime = function(id,data){
		$scope.startTime[id] = TimeGeneration(data,2); 
	};
	TimeGeneration = function(num,state){
		optoins = [];
		start = 8;
		end = 23;
		if(state == 1){ start = parseFloat(num.start_time); }
		if(state == 2){ end = parseFloat(num.end_time); }
		for(var i = start; i < end; i+=0.15) {
			time = i.toFixed(2);
			min = (time%1).toFixed(2);
			if(min == 0.60) {
				i+= 0.40;
				val = i.toFixed(2);
				if(parseFloat(val) < 10){
					op = float2int(val)+":"+val.split(".")[1];
					optoins.push({label:op,value:'0'+val});
				}else{
					op = float2int(val)+":"+val.split(".")[1];
					optoins.push({label:op,value:val});
				}
				continue;
			};
			if(parseFloat(time) < 10){
				op = float2int(time)+":"+time.split(".")[1];
				optoins.push({label:op,value:'0'+time});
			}else{
				op = float2int(time)+":"+time.split(".")[1];
				optoins.push({label:op,value:time});
			}
		}
		if(state == 1){	optoins.shift(); }
		if(state == 2){	optoins.pop(); }
		return optoins;
	};
	float2int = function(value) {
		return value | 0;
	}	
	$scope.timezoneOptions.push(
		{value:"Africa/Abidjan",lable:"Africa/Abidjan"},
		{value:"Africa/Accra",lable:"Africa/Accra"},
		{value:"Africa/Addis_Ababa",lable:"Africa/Addis_Ababa"},
		{value:"Africa/Algiers",lable:"Africa/Algiers"},
		{value:"Africa/Asmara",lable:"Africa/Asmara"},
		{value:"Africa/Bamako",lable:"Africa/Bamako"},
		{value:"Africa/Bangui",lable:"Africa/Bangui"},
		{value:"Africa/Banjul",lable:"Africa/Banjul"},
		{value:"Africa/Bissau",lable:"Africa/Bissau"},
		{value:"Africa/Blantyre",lable:"Africa/Blantyre"},
		{value:"Africa/Brazzaville",lable:"Africa/Brazzaville"},
		{value:"Africa/Bujumbura",lable:"Africa/Bujumbura"},
		{value:"Africa/Cairo",lable:"Africa/Cairo"},
		{value:"Africa/Casablanca",lable:"Africa/Casablanca"},
		{value:"Africa/Ceuta",lable:"Africa/Ceuta"},
		{value:"Africa/Conakry",lable:"Africa/Conakry"},
		{value:"Africa/Dakar",lable:"Africa/Dakar"},
		{value:"Africa/Dar_es_Salaam",lable:"Africa/Dar_es_Salaam"},
		{value:"Africa/Djibouti",lable:"Africa/Djibouti"},
		{value:"Africa/Douala",lable:"Africa/Douala"},
		{value:"Africa/El_Aaiun",lable:"Africa/El_Aaiun"},
		{value:"Africa/Freetown",lable:"Africa/Freetown"},
		{value:"Africa/Gaborone",lable:"Africa/Gaborone"},
		{value:"Africa/Harare",lable:"Africa/Harare"},
		{value:"Africa/Johannesburg",lable:"Africa/Johannesburg"},
		{value:"Africa/Juba",lable:"Africa/Juba"},
		{value:"Africa/Kampala",lable:"Africa/Kampala"},
		{value:"Africa/Khartoum",lable:"Africa/Khartoum"},
		{value:"Africa/Kigali",lable:"Africa/Kigali"},
		{value:"Africa/Kinshasa",lable:"Africa/Kinshasa"},
		{value:"Africa/Lagos",lable:"Africa/Lagos"},
		{value:"Africa/Libreville",lable:"Africa/Libreville"},
		{value:"Africa/Lome",lable:"Africa/Lome"},
		{value:"Africa/Luanda",lable:"Africa/Luanda"},
		{value:"Africa/Lubumbashi",lable:"Africa/Lubumbashi"},
		{value:"Africa/Lusaka",lable:"Africa/Lusaka"},
		{value:"Africa/Malabo",lable:"Africa/Malabo"},
		{value:"Africa/Maputo",lable:"Africa/Maputo"},
		{value:"Africa/Maseru",lable:"Africa/Maseru"},
		{value:"Africa/Mbabane",lable:"Africa/Mbabane"},
		{value:"Africa/Mogadishu",lable:"Africa/Mogadishu"},
		{value:"Africa/Monrovia",lable:"Africa/Monrovia"},
		{value:"Africa/Nairobi",lable:"Africa/Nairobi"},
		{value:"Africa/Ndjamena",lable:"Africa/Ndjamena"},
		{value:"Africa/Niamey",lable:"Africa/Niamey"},
		{value:"Africa/Nouakchott",lable:"Africa/Nouakchott"},
		{value:"Africa/Ouagadougou",lable:"Africa/Ouagadougou"},
		{value:"Africa/Porto-Novo",lable:"Africa/Porto-Novo"},
		{value:"Africa/Sao_Tome",lable:"Africa/Sao_Tome"},
		{value:"Africa/Tripoli",lable:"Africa/Tripoli"},
		{value:"Africa/Tunis",lable:"Africa/Tunis"},
		{value:"Africa/Windhoek",lable:"Africa/Windhoek"},
		{value:"America/Adak",lable:"America/Adak"},
		{value:"America/Anchorage",lable:"America/Anchorage"},
		{value:"America/Anguilla",lable:"America/Anguilla"},
		{value:"America/Antigua",lable:"America/Antigua"},
		{value:"America/Araguaina",lable:"America/Araguaina"},
		{value:"America/Argentina/Buenos_Aires",lable:"America/Argentina/Buenos_Aires"},
		{value:"America/Argentina/Catamarca",lable:"America/Argentina/Catamarca"},
		{value:"America/Argentina/Cordoba",lable:"America/Argentina/Cordoba"},
		{value:"America/Argentina/Jujuy",lable:"America/Argentina/Jujuy"},
		{value:"America/Argentina/La_Rioja",lable:"America/Argentina/La_Rioja"},
		{value:"America/Argentina/Mendoza",lable:"America/Argentina/Mendoza"},
		{value:"America/Argentina/Rio_Gallegos",lable:"America/Argentina/Rio_Gallegos"},
		{value:"America/Argentina/Salta",lable:"America/Argentina/Salta"},
		{value:"America/Argentina/San_Juan",lable:"America/Argentina/San_Juan"},
		{value:"America/Argentina/San_Luis",lable:"America/Argentina/San_Luis"},
		{value:"America/Argentina/Tucuman",lable:"America/Argentina/Tucuman"},
		{value:"America/Argentina/Ushuaia",lable:"America/Argentina/Ushuaia"},
		{value:"America/Aruba",lable:"America/Aruba"},
		{value:"America/Asuncion",lable:"America/Asuncion"},
		{value:"America/Atikokan",lable:"America/Atikokan"},
		{value:"America/Bahia",lable:"America/Bahia"},
		{value:"America/Bahia_Banderas",lable:"America/Bahia_Banderas"},
		{value:"America/Barbados",lable:"America/Barbados"},
		{value:"America/Belem",lable:"America/Belem"},
		{value:"America/Belize",lable:"America/Belize"},
		{value:"America/Blanc-Sablon",lable:"America/Blanc-Sablon"},
		{value:"America/Boa_Vista",lable:"America/Boa_Vista"},
		{value:"America/Bogota",lable:"America/Bogota"},
		{value:"America/Boise",lable:"America/Boise"},
		{value:"America/Cambridge_Bay",lable:"America/Cambridge_Bay"},
		{value:"America/Campo_Grande",lable:"America/Campo_Grande"},
		{value:"America/Cancun",lable:"America/Cancun"},
		{value:"America/Caracas",lable:"America/Caracas"},
		{value:"America/Cayenne",lable:"America/Cayenne"},
		{value:"America/Cayman",lable:"America/Cayman"},
		{value:"America/Chicago",lable:"America/Chicago"},
		{value:"America/Chihuahua",lable:"America/Chihuahua"},
		{value:"America/Costa_Rica",lable:"America/Costa_Rica"},
		{value:"America/Creston",lable:"America/Creston"},
		{value:"America/Cuiaba",lable:"America/Cuiaba"},
		{value:"America/Curacao",lable:"America/Curacao"},
		{value:"America/Danmarkshavn",lable:"America/Danmarkshavn"},
		{value:"America/Dawson",lable:"America/Dawson"},
		{value:"America/Dawson_Creek",lable:"America/Dawson_Creek"},
		{value:"America/Denver",lable:"America/Denver"},
		{value:"America/Detroit",lable:"America/Detroit"},
		{value:"America/Dominica",lable:"America/Dominica"},
		{value:"America/Edmonton",lable:"America/Edmonton"},
		{value:"America/Eirunepe",lable:"America/Eirunepe"},
		{value:"America/El_Salvador",lable:"America/El_Salvador"},
		{value:"America/Fortaleza",lable:"America/Fortaleza"},
		{value:"America/Glace_Bay",lable:"America/Glace_Bay"},
		{value:"America/Godthab",lable:"America/Godthab"},
		{value:"America/Goose_Bay",lable:"America/Goose_Bay"},
		{value:"America/Grand_Turk",lable:"America/Grand_Turk"},
		{value:"America/Grenada",lable:"America/Grenada"},
		{value:"America/Guadeloupe",lable:"America/Guadeloupe"},
		{value:"America/Guatemala",lable:"America/Guatemala"},
		{value:"America/Guayaquil",lable:"America/Guayaquil"},
		{value:"America/Guyana",lable:"America/Guyana"},
		{value:"America/Halifax",lable:"America/Halifax"},
		{value:"America/Havana",lable:"America/Havana"},
		{value:"America/Hermosillo",lable:"America/Hermosillo"},
		{value:"America/Indiana/Indianapolis",lable:"America/Indiana/Indianapolis"},
		{value:"America/Indiana/Knox",lable:"America/Indiana/Knox"},
		{value:"America/Indiana/Marengo",lable:"America/Indiana/Marengo"},
		{value:"America/Indiana/Petersburg",lable:"America/Indiana/Petersburg"},
		{value:"America/Indiana/Tell_City",lable:"America/Indiana/Tell_City"},
		{value:"America/Indiana/Vevay",lable:"America/Indiana/Vevay"},
		{value:"America/Indiana/Vincennes",lable:"America/Indiana/Vincennes"},
		{value:"America/Indiana/Winamac",lable:"America/Indiana/Winamac"},
		{value:"America/Inuvik",lable:"America/Inuvik"},
		{value:"America/Iqaluit",lable:"America/Iqaluit"},
		{value:"America/Jamaica",lable:"America/Jamaica"},
		{value:"America/Juneau",lable:"America/Juneau"},
		{value:"America/Kentucky/Louisville",lable:"America/Kentucky/Louisville"},
		{value:"America/Kentucky/Monticello",lable:"America/Kentucky/Monticello"},
		{value:"America/Kralendijk",lable:"America/Kralendijk"},
		{value:"America/La_Paz",lable:"America/La_Paz"},
		{value:"America/Lima",lable:"America/Lima"},
		{value:"America/Los_Angeles",lable:"America/Los_Angeles"},
		{value:"America/Lower_Princes",lable:"America/Lower_Princes"},
		{value:"America/Maceio",lable:"America/Maceio"},
		{value:"America/Managua",lable:"America/Managua"},
		{value:"America/Manaus",lable:"America/Manaus"},
		{value:"America/Marigot",lable:"America/Marigot"},
		{value:"America/Martinique",lable:"America/Martinique"},
		{value:"America/Matamoros",lable:"America/Matamoros"},
		{value:"America/Mazatlan",lable:"America/Mazatlan"},
		{value:"America/Menominee",lable:"America/Menominee"},
		{value:"America/Merida",lable:"America/Merida"},
		{value:"America/Metlakatla",lable:"America/Metlakatla"},
		{value:"America/Mexico_City",lable:"America/Mexico_City"},
		{value:"America/Miquelon",lable:"America/Miquelon"},
		{value:"America/Moncton",lable:"America/Moncton"},
		{value:"America/Monterrey",lable:"America/Monterrey"},
		{value:"America/Montevideo",lable:"America/Montevideo"},
		{value:"America/Montserrat",lable:"America/Montserrat"},
		{value:"America/Nassau",lable:"America/Nassau"},
		{value:"America/New_York",lable:"America/New_York"},
		{value:"America/Nipigon",lable:"America/Nipigon"},
		{value:"America/Nome",lable:"America/Nome"},
		{value:"America/Noronha",lable:"America/Noronha"},
		{value:"America/North_Dakota/Beulah",lable:"America/North_Dakota/Beulah"},
		{value:"America/North_Dakota/Center",lable:"America/North_Dakota/Center"},
		{value:"America/North_Dakota/New_Salem",lable:"America/North_Dakota/New_Salem"},
		{value:"America/Ojinaga",lable:"America/Ojinaga"},
		{value:"America/Panama",lable:"America/Panama"},
		{value:"America/Pangnirtung",lable:"America/Pangnirtung"},
		{value:"America/Paramaribo",lable:"America/Paramaribo"},
		{value:"America/Phoenix",lable:"America/Phoenix"},
		{value:"America/Port-au-Prince",lable:"America/Port-au-Prince"},
		{value:"America/Port_of_Spain",lable:"America/Port_of_Spain"},
		{value:"America/Porto_Velho",lable:"America/Porto_Velho"},
		{value:"America/Puerto_Rico",lable:"America/Puerto_Rico"},
		{value:"America/Rainy_River",lable:"America/Rainy_River"},
		{value:"America/Rankin_Inlet",lable:"America/Rankin_Inlet"},
		{value:"America/Recife",lable:"America/Recife"},
		{value:"America/Regina",lable:"America/Regina"},
		{value:"America/Resolute",lable:"America/Resolute"},
		{value:"America/Rio_Branco",lable:"America/Rio_Branco"},
		{value:"America/Santa_Isabel",lable:"America/Santa_Isabel"},
		{value:"America/Santarem",lable:"America/Santarem"},
		{value:"America/Santiago",lable:"America/Santiago"},
		{value:"America/Santo_Domingo",lable:"America/Santo_Domingo"},
		{value:"America/Sao_Paulo",lable:"America/Sao_Paulo"},
		{value:"America/Scoresbysund",lable:"America/Scoresbysund"},
		{value:"America/Sitka",lable:"America/Sitka"},
		{value:"America/St_Barthelemy",lable:"America/St_Barthelemy"},
		{value:"America/St_Johns",lable:"America/St_Johns"},
		{value:"America/St_Kitts",lable:"America/St_Kitts"},
		{value:"America/St_Lucia",lable:"America/St_Lucia"},
		{value:"America/St_Thomas",lable:"America/St_Thomas"},
		{value:"America/St_Vincent",lable:"America/St_Vincent"},
		{value:"America/Swift_Current",lable:"America/Swift_Current"},
		{value:"America/Tegucigalpa",lable:"America/Tegucigalpa"},
		{value:"America/Thule",lable:"America/Thule"},
		{value:"America/Thunder_Bay",lable:"America/Thunder_Bay"},
		{value:"America/Tijuana",lable:"America/Tijuana"},
		{value:"America/Toronto",lable:"America/Toronto"},
		{value:"America/Tortola",lable:"America/Tortola"},
		{value:"America/Vancouver",lable:"America/Vancouver"},
		{value:"America/Whitehorse",lable:"America/Whitehorse"},
		{value:"America/Winnipeg",lable:"America/Winnipeg"},
		{value:"America/Yakutat",lable:"America/Yakutat"},
		{value:"America/Yellowknife",lable:"America/Yellowknife"},
		{value:"Antarctica/Casey",lable:"Antarctica/Casey"},
		{value:"Antarctica/Davis",lable:"Antarctica/Davis"},
		{value:"Antarctica/DumontDUrville",lable:"Antarctica/DumontDUrville"},
		{value:"Antarctica/Macquarie",lable:"Antarctica/Macquarie"},
		{value:"Antarctica/Mawson",lable:"Antarctica/Mawson"},
		{value:"Antarctica/McMurdo",lable:"Antarctica/McMurdo"},
		{value:"Antarctica/Palmer",lable:"Antarctica/Palmer"},
		{value:"Antarctica/Rothera",lable:"Antarctica/Rothera"},
		{value:"Antarctica/Syowa",lable:"Antarctica/Syowa"},
		{value:"Antarctica/Vostok",lable:"Antarctica/Vostok"},
		{value:"Arctic/Longyearbyen",lable:"Arctic/Longyearbyen"},
		{value:"Asia/Aden",lable:"Asia/Aden"},
		{value:"Asia/Almaty",lable:"Asia/Almaty"},
		{value:"Asia/Amman",lable:"Asia/Amman"},
		{value:"Asia/Anadyr",lable:"Asia/Anadyr"},
		{value:"Asia/Aqtau",lable:"Asia/Aqtau"},
		{value:"Asia/Aqtobe",lable:"Asia/Aqtobe"},
		{value:"Asia/Ashgabat",lable:"Asia/Ashgabat"},
		{value:"Asia/Baghdad",lable:"Asia/Baghdad"},
		{value:"Asia/Bahrain",lable:"Asia/Bahrain"},
		{value:"Asia/Baku",lable:"Asia/Baku"},
		{value:"Asia/Bangkok",lable:"Asia/Bangkok"},
		{value:"Asia/Beirut",lable:"Asia/Beirut"},
		{value:"Asia/Bishkek",lable:"Asia/Bishkek"},
		{value:"Asia/Brunei",lable:"Asia/Brunei"},
		{value:"Asia/Choibalsan",lable:"Asia/Choibalsan"},
		{value:"Asia/Chongqing",lable:"Asia/Chongqing"},
		{value:"Asia/Colombo",lable:"Asia/Colombo"},
		{value:"Asia/Damascus",lable:"Asia/Damascus"},
		{value:"Asia/Dhaka",lable:"Asia/Dhaka"},
		{value:"Asia/Dili",lable:"Asia/Dili"},
		{value:"Asia/Dubai",lable:"Asia/Dubai"},
		{value:"Asia/Dushanbe",lable:"Asia/Dushanbe"},
		{value:"Asia/Gaza",lable:"Asia/Gaza"},
		{value:"Asia/Harbin",lable:"Asia/Harbin"},
		{value:"Asia/Hebron",lable:"Asia/Hebron"},
		{value:"Asia/Ho_Chi_Minh",lable:"Asia/Ho_Chi_Minh"},
		{value:"Asia/Hong_Kong",lable:"Asia/Hong_Kong"},
		{value:"Asia/Hovd",lable:"Asia/Hovd"},
		{value:"Asia/Irkutsk",lable:"Asia/Irkutsk"},
		{value:"Asia/Jakarta",lable:"Asia/Jakarta"},
		{value:"Asia/Jayapura",lable:"Asia/Jayapura"},
		{value:"Asia/Jerusalem",lable:"Asia/Jerusalem"},
		{value:"Asia/Kabul",lable:"Asia/Kabul"},
		{value:"Asia/Kamchatka",lable:"Asia/Kamchatka"},
		{value:"Asia/Karachi",lable:"Asia/Karachi"},
		{value:"Asia/Kashgar",lable:"Asia/Kashgar"},
		{value:"Asia/Kathmandu",lable:"Asia/Kathmandu"},
		{value:"Asia/Khandyga",lable:"Asia/Khandyga"},
		{value:"Asia/Kolkata",lable:"Asia/Kolkata"},
		{value:"Asia/Krasnoyarsk",lable:"Asia/Krasnoyarsk"},
		{value:"Asia/Kuala_Lumpur",lable:"Asia/Kuala_Lumpur"},
		{value:"Asia/Kuching",lable:"Asia/Kuching"},
		{value:"Asia/Kuwait",lable:"Asia/Kuwait"},
		{value:"Asia/Macau",lable:"Asia/Macau"},
		{value:"Asia/Magadan",lable:"Asia/Magadan"},
		{value:"Asia/Makassar",lable:"Asia/Makassar"},
		{value:"Asia/Manila",lable:"Asia/Manila"},
		{value:"Asia/Muscat",lable:"Asia/Muscat"},
		{value:"Asia/Nicosia",lable:"Asia/Nicosia"},
		{value:"Asia/Novokuznetsk",lable:"Asia/Novokuznetsk"},
		{value:"Asia/Novosibirsk",lable:"Asia/Novosibirsk"},
		{value:"Asia/Omsk",lable:"Asia/Omsk"},
		{value:"Asia/Oral",lable:"Asia/Oral"},
		{value:"Asia/Phnom_Penh",lable:"Asia/Phnom_Penh"},
		{value:"Asia/Pontianak",lable:"Asia/Pontianak"},
		{value:"Asia/Pyongyang",lable:"Asia/Pyongyang"},
		{value:"Asia/Qatar",lable:"Asia/Qatar"},
		{value:"Asia/Qyzylorda",lable:"Asia/Qyzylorda"},
		{value:"Asia/Rangoon",lable:"Asia/Rangoon"},
		{value:"Asia/Riyadh",lable:"Asia/Riyadh"},
		{value:"Asia/Sakhalin",lable:"Asia/Sakhalin"},
		{value:"Asia/Samarkand",lable:"Asia/Samarkand"},
		{value:"Asia/Seoul",lable:"Asia/Seoul"},
		{value:"Asia/Shanghai",lable:"Asia/Shanghai"},
		{value:"Asia/Singapore",lable:"Asia/Singapore"},
		{value:"Asia/Taipei",lable:"Asia/Taipei"},
		{value:"Asia/Tashkent",lable:"Asia/Tashkent"},
		{value:"Asia/Tbilisi",lable:"Asia/Tbilisi"},
		{value:"Asia/Tehran",lable:"Asia/Tehran"},
		{value:"Asia/Thimphu",lable:"Asia/Thimphu"},
		{value:"Asia/Tokyo",lable:"Asia/Tokyo"},
		{value:"Asia/Ulaanbaatar",lable:"Asia/Ulaanbaatar"},
		{value:"Asia/Urumqi",lable:"Asia/Urumqi"},
		{value:"Asia/Ust-Nera",lable:"Asia/Ust-Nera"},
		{value:"Asia/Vientiane",lable:"Asia/Vientiane"},
		{value:"Asia/Vladivostok",lable:"Asia/Vladivostok"},
		{value:"Asia/Yakutsk",lable:"Asia/Yakutsk"},
		{value:"Asia/Yekaterinburg",lable:"Asia/Yekaterinburg"},
		{value:"Asia/Yerevan",lable:"Asia/Yerevan"},
		{value:"Atlantic/Azores",lable:"Atlantic/Azores"},
		{value:"Atlantic/Bermuda",lable:"Atlantic/Bermuda"},
		{value:"Atlantic/Canary",lable:"Atlantic/Canary"},
		{value:"Atlantic/Cape_Verde",lable:"Atlantic/Cape_Verde"},
		{value:"Atlantic/Faroe",lable:"Atlantic/Faroe"},
		{value:"Atlantic/Madeira",lable:"Atlantic/Madeira"},
		{value:"Atlantic/Reykjavik",lable:"Atlantic/Reykjavik"},
		{value:"Atlantic/South_Georgia",lable:"Atlantic/South_Georgia"},
		{value:"Atlantic/St_Helena",lable:"Atlantic/St_Helena"},
		{value:"Atlantic/Stanley",lable:"Atlantic/Stanley"},
		{value:"Australia/Adelaide",lable:"Australia/Adelaide"},
		{value:"Australia/Brisbane",lable:"Australia/Brisbane"},
		{value:"Australia/Broken_Hill",lable:"Australia/Broken_Hill"},
		{value:"Australia/Currie",lable:"Australia/Currie"},
		{value:"Australia/Darwin",lable:"Australia/Darwin"},
		{value:"Australia/Eucla",lable:"Australia/Eucla"},
		{value:"Australia/Hobart",lable:"Australia/Hobart"},
		{value:"Australia/Lindeman",lable:"Australia/Lindeman"},
		{value:"Australia/Lord_Howe",lable:"Australia/Lord_Howe"},
		{value:"Australia/Melbourne",lable:"Australia/Melbourne"},
		{value:"Australia/Perth",lable:"Australia/Perth"},
		{value:"Australia/Sydney",lable:"Australia/Sydney"},
		{value:"Europe/Amsterdam",lable:"Europe/Amsterdam"},
		{value:"Europe/Andorra",lable:"Europe/Andorra"},
		{value:"Europe/Athens",lable:"Europe/Athens"},
		{value:"Europe/Belgrade",lable:"Europe/Belgrade"},
		{value:"Europe/Berlin",lable:"Europe/Berlin"},
		{value:"Europe/Bratislava",lable:"Europe/Bratislava"},
		{value:"Europe/Brussels",lable:"Europe/Brussels"},
		{value:"Europe/Bucharest",lable:"Europe/Bucharest"},
		{value:"Europe/Budapest",lable:"Europe/Budapest"},
		{value:"Europe/Busingen",lable:"Europe/Busingen"},
		{value:"Europe/Chisinau",lable:"Europe/Chisinau"},
		{value:"Europe/Copenhagen",lable:"Europe/Copenhagen"},
		{value:"Europe/Dublin",lable:"Europe/Dublin"},
		{value:"Europe/Gibraltar",lable:"Europe/Gibraltar"},
		{value:"Europe/Guernsey",lable:"Europe/Guernsey"},
		{value:"Europe/Helsinki",lable:"Europe/Helsinki"},
		{value:"Europe/Isle_of_Man",lable:"Europe/Isle_of_Man"},
		{value:"Europe/Istanbul",lable:"Europe/Istanbul"},
		{value:"Europe/Jersey",lable:"Europe/Jersey"},
		{value:"Europe/Kaliningrad",lable:"Europe/Kaliningrad"},
		{value:"Europe/Kiev",lable:"Europe/Kiev"},
		{value:"Europe/Lisbon",lable:"Europe/Lisbon"},
		{value:"Europe/Ljubljana",lable:"Europe/Ljubljana"},
		{value:"Europe/London",lable:"Europe/London"},
		{value:"Europe/Luxembourg",lable:"Europe/Luxembourg"},
		{value:"Europe/Madrid",lable:"Europe/Madrid"},
		{value:"Europe/Malta",lable:"Europe/Malta"},
		{value:"Europe/Mariehamn",lable:"Europe/Mariehamn"},
		{value:"Europe/Minsk",lable:"Europe/Minsk"},
		{value:"Europe/Monaco",lable:"Europe/Monaco"},
		{value:"Europe/Moscow",lable:"Europe/Moscow"},
		{value:"Europe/Oslo",lable:"Europe/Oslo"},
		{value:"Europe/Paris",lable:"Europe/Paris"},
		{value:"Europe/Podgorica",lable:"Europe/Podgorica"},
		{value:"Europe/Prague",lable:"Europe/Prague"},
		{value:"Europe/Riga",lable:"Europe/Riga"},
		{value:"Europe/Rome",lable:"Europe/Rome"},
		{value:"Europe/Samara",lable:"Europe/Samara"},
		{value:"Europe/San_Marino",lable:"Europe/San_Marino"},
		{value:"Europe/Sarajevo",lable:"Europe/Sarajevo"},
		{value:"Europe/Simferopol",lable:"Europe/Simferopol"},
		{value:"Europe/Skopje",lable:"Europe/Skopje"},
		{value:"Europe/Sofia",lable:"Europe/Sofia"},
		{value:"Europe/Stockholm",lable:"Europe/Stockholm"},
		{value:"Europe/Tallinn",lable:"Europe/Tallinn"},
		{value:"Europe/Tirane",lable:"Europe/Tirane"},
		{value:"Europe/Uzhgorod",lable:"Europe/Uzhgorod"},
		{value:"Europe/Vaduz",lable:"Europe/Vaduz"},
		{value:"Europe/Vatican",lable:"Europe/Vatican"},
		{value:"Europe/Vienna",lable:"Europe/Vienna"},
		{value:"Europe/Vilnius",lable:"Europe/Vilnius"},
		{value:"Europe/Volgograd",lable:"Europe/Volgograd"},
		{value:"Europe/Warsaw",lable:"Europe/Warsaw"},
		{value:"Europe/Zagreb",lable:"Europe/Zagreb"},
		{value:"Europe/Zaporozhye",lable:"Europe/Zaporozhye"},
		{value:"Europe/Zurich",lable:"Europe/Zurich"},
		{value:"Indian/Antananarivo",lable:"Indian/Antananarivo"},
		{value:"Indian/Chagos",lable:"Indian/Chagos"},
		{value:"Indian/Christmas",lable:"Indian/Christmas"},
		{value:"Indian/Cocos",lable:"Indian/Cocos"},
		{value:"Indian/Comoro",lable:"Indian/Comoro"},
		{value:"Indian/Kerguelen",lable:"Indian/Kerguelen"},
		{value:"Indian/Mahe",lable:"Indian/Mahe"},
		{value:"Indian/Maldives",lable:"Indian/Maldives"},
		{value:"Indian/Mauritius",lable:"Indian/Mauritius"},
		{value:"Indian/Mayotte",lable:"Indian/Mayotte"},
		{value:"Indian/Reunion",lable:"Indian/Reunion"},
		{value:"Pacific/Apia",lable:"Pacific/Apia"},
		{value:"Pacific/Auckland",lable:"Pacific/Auckland"},
		{value:"Pacific/Chatham",lable:"Pacific/Chatham"},
		{value:"Pacific/Chuuk",lable:"Pacific/Chuuk"},
		{value:"Pacific/Easter",lable:"Pacific/Easter"},
		{value:"Pacific/Efate",lable:"Pacific/Efate"},
		{value:"Pacific/Enderbury",lable:"Pacific/Enderbury"},
		{value:"Pacific/Fakaofo",lable:"Pacific/Fakaofo"},
		{value:"Pacific/Fiji",lable:"Pacific/Fiji"},
		{value:"Pacific/Funafuti",lable:"Pacific/Funafuti"},
		{value:"Pacific/Galapagos",lable:"Pacific/Galapagos"},
		{value:"Pacific/Gambier",lable:"Pacific/Gambier"},
		{value:"Pacific/Guadalcanal",lable:"Pacific/Guadalcanal"},
		{value:"Pacific/Guam",lable:"Pacific/Guam"},
		{value:"Pacific/Honolulu",lable:"Pacific/Honolulu"},
		{value:"Pacific/Johnston",lable:"Pacific/Johnston"},
		{value:"Pacific/Kiritimati",lable:"Pacific/Kiritimati"},
		{value:"Pacific/Kosrae",lable:"Pacific/Kosrae"},
		{value:"Pacific/Kwajalein",lable:"Pacific/Kwajalein"},
		{value:"Pacific/Majuro",lable:"Pacific/Majuro"},
		{value:"Pacific/Marquesas",lable:"Pacific/Marquesas"},
		{value:"Pacific/Midway",lable:"Pacific/Midway"},
		{value:"Pacific/Nauru",lable:"Pacific/Nauru"},
		{value:"Pacific/Niue",lable:"Pacific/Niue"},
		{value:"Pacific/Norfolk",lable:"Pacific/Norfolk"},
		{value:"Pacific/Noumea",lable:"Pacific/Noumea"},
		{value:"Pacific/Pago_Pago",lable:"Pacific/Pago_Pago"},
		{value:"Pacific/Palau",lable:"Pacific/Palau"},
		{value:"Pacific/Pitcairn",lable:"Pacific/Pitcairn"},
		{value:"Pacific/Pohnpei",lable:"Pacific/Pohnpei"},
		{value:"Pacific/Port_Moresby",lable:"Pacific/Port_Moresby"},
		{value:"Pacific/Rarotonga",lable:"Pacific/Rarotonga"},
		{value:"Pacific/Saipan",lable:"Pacific/Saipan"},
		{value:"Pacific/Tahiti",lable:"Pacific/Tahiti"},
		{value:"Pacific/Tarawa",lable:"Pacific/Tarawa"},
		{value:"Pacific/Tongatapu",lable:"Pacific/Tongatapu"},
		{value:"Pacific/Wake",lable:"Pacific/Wake"},
		{value:"Pacific/Wallis",lable:"Pacific/Wallis"},
		{value:"UTC",lable:"UTC"}
	);
}]);