angular.module('SharendaApp.Professionnel',[])
.config(['$routeProvider',function($routeProvider) {
	$routeProvider
	.when('/professionnel',{
		controller: 'ProfessionnelController',
		templateUrl: BASE_URL+'/ng/professionnel/professionnel.tpl.html'
	});
}])
.directive('weekcal',function($compile) {
	return {
		type:'A',
		link:function(scope,element,attrs){
			$(element).weekCalendar({
				dateFormat: "d M Y",
				data: function(start,end){
					$(".wc-nav .wc-today").hide();
					setTimeout(function(){
						scope.spots($compile);
					},30);
				},
			});
		}
	}
})
.directive('selectric',function($compile) {
	return {
		type:'A',
		link:function(scope,element,attrs){
			$(element).selectric();
			if(attrs.id == 'comm_method'){
				scope.$watch('commMethod',function() {
					if(scope.commMethod != undefined && scope.commMethod.length >= 1){
						$(element).empty();
						angular.forEach(scope.commMethod,function(value,key){
							$(element).append('<option value="'+value.id+'">'+value.name+'</option>');
						});
						$(element).selectric('refresh');
						scope.clientEvent.comm_method = $(element).val();
					}else{
						scope.clientEvent.comm_method = null;						
					}
				});
			}else{
				scope.$watch('EventUser',function() {
					if(scope.EventUser.purpose != undefined && scope.EventUser.purpose.length >= 1){
						$(element).empty();
						angular.forEach(scope.EventUser.purpose,function(value,key){
							if(value.status == true){
                                      					$(element).append('<option value="'+value.id+'">'+value.name+'</option>');
                                      				}
						});
						$(element).selectric('refresh');
						scope.clientEvent.purpose = $(element).val();
					}
				});
			}
		}
	}
})
.directive('selectize',function($compile) {
	return {
		type:'A',
		link:function(scope,element,attrs){
			// if(attrs.id == 'specialty'){$(element)[0].selectize.clearOptions();}
			setTimeout(function() {
				$(element).selectize({
					sortField: [],
					create:true,
				});
			},600);
		}
	}
})
.directive('address',function($compile) {
	return {
		type:'A',
		link:function(scope,element,attrs){
			$( function() {
		                     var addressPicker = new AddressPicker({
		                          autocompleteService: {
		                               // types: ['(cities)'],
		                               componentRestrictions: {country: 'fr'}
		                          }
		                     });
		                     $(element).typeahead(null, {
		                          displayKey: 'description',
		                          source: addressPicker.ttAdapter()
		                     });
		                     addressPicker.bindDefaultTypeaheadEvent(element)
		                     $(addressPicker).on('addresspicker:selected',function(event,result) {
		                     	scope.event.city = result.nameForType('locality');
		                     })
		                     $(addressPicker).on('addresspicker:predictions',function(event,result) {
		                          if(result && result.length > 0)
		                                $(element).removeClass("empty")
		                          else
		                                $(element).addClass("empty")
		                     })
		           });		
		}
	}
})
.directive('eventdate',function($compile) {
	return {
		type:'A',
		link:function(scope,element,attrs){
			var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
			var d = new Date();
			$.datepicker.setDefaults($.datepicker.regional['fr']);
			$(element).datepicker({
				minDate: 0,
				dateFormat:'dd/mm/yy',
				beforeShowDay: function(date) {
					disable = true;
					var range = '';
					if(!($.isEmptyObject(scope.EventUser.offline))  && scope.EventUser.offline.status){
                                     			var st_date = moment(scope.EventUser.offline.start_date,"YYYY-MM-DD");
                                     			var end_date = moment(scope.EventUser.offline.end_date,"YYYY-MM-DD");
                                     			range = moment.range(st_date,end_date);
                                		}
                                		offline_date = moment(date);
                                		if(!($.isEmptyObject(scope.EventUser.offline))  && scope.EventUser.offline.status && offline_date.within(range)){
                                			disable = false;
                                		}
					$.each(scope.EventUser.schedule,function(key,value){
						day = date.getDay();
						if(weekday[day] == value.day && value.status == 0){
							disable = false;
						}
					});
					return [disable];
				}
			}).on('change',function(e) {
				 value = $(element).val();
				 date = moment(value,'DD/MM/YYYY').format('YYYY-MM-DD');
				 day = scope.dayOfWeek(date);
				 $(element).val(moment(value,'DD/MM/YYYY').format('DD/MM/YYYY'));
				 scope.clientEvent.start = moment(value,'DD/MM/YYYY').format('DD/MM/YYYY');
				 $.each(scope.EventUser.schedule,function(key,value){
				 	if(day===value.day && value.status != false){
				 		start_time = moment(value.start_time,"HH:mm:ss").format('HH.mm');
				 		end_time = moment(value.end_time,"HH:mm:ss").format('HH.mm');
				 		options = scope.timefunction(start_time,end_time);
				 		$select = $(document.getElementById('timeoption')).selectize(options);
				 		selectize = $select[0].selectize;
				 		selectize.clearOptions();
				 		$.each(options,function(key,val){
				 			ele = scope.removeTimes(date,val.value);
                                          			if(!ele[0]){
                                          				selectize.addOption(val);
                                          			}
				 		});
				 		selectize.refreshOptions();
				 	}
				 });
			});
		}
	};
})
.factory('SearchService',function($http) {
	 searchService = {};
	 searchService.getInfo = function(data,callback) {
	 	$http.post(window.BASE_URL+'search/search',data).success(function(res) {
	 		callback(res);
	 	});
	 };
 	return searchService;
})
.factory('ClientEventService',function($http) {
	clientEventService = {};
	clientEventService.postAppointment = function(data,callback) {
	 	$http.post(window.BASE_URL+'client/event-create',data).success(function(res) {
	 		callback(res);
	 	}).error(function(res){
	 		callback(res);
	 	});
	 };
 	return clientEventService;
})
.controller('ProfessionnelController',['$scope','$compile','ProfileService','AlertService','SearchService','ClientEventService','$timeout',function($scope,$compile,ProfileService,AlertService,SearchService,ClientEventService,$timeout) {
	$scope.profession = {};
	$scope.specialty = {};
	$scope.event = {};
	$scope.searchUser = {};
	$scope.specialties = [];
	$scope.EventUser = {};
	$scope.offset = 0;
	$scope.numbers = [];
	$scope.total = null;
	$scope.clientEvent = {};
	$scope.clientEvent.duration = 0;
	$scope.commMethod = {};
	$scope.questions = {};
	ProfileService.getProf(function(data) {
		$scope.profession=data.profession;
		$scope.changeProfessionHandler($scope.profession[0]);
	});
	$scope.datePlace = Date.parse(Date());
	$scope.removeTimes = function(start,time){
                     return $.grep($scope.EventUser.daytimes,function(n,i){
                               return n.start == start && n.time == time;
                     });
           };
	$scope.changeProfessionHandler = function(data){
		// $('#specialty').next().find(".selectize-dropdown-content").empty();
		if(data.id!=null){
			id = data.id;
		}else{
			id = data.profession;
		}
		specialty = [];
		angular.forEach($scope.profession,function(value,key){
			if(id==value.id){ 
				angular.forEach(value.specialty,function(item){
					specialty.push(item);
				});
			}
		});
		$scope.specialty = specialty;
		$("#specialty").html('');
		$scope.event.profession = id;
		$scope.event.specialty = $scope.specialty[0].id;
	};
	$scope.dayOfWeek = function(d) {
		var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
		var nData = new Date(d);
		return weekday[nData.getDay()];
          };
	$scope.CreateEvent = function(data){
		data.offset = 0;
		data.profession = data.profession[0];
		data.specialty = data.specialty[0];
		SearchService.getInfo(data,function(res) {
			$scope.questions = res.question;
			$scope.commMethod = res.commMethod;
			numbers = [];
			$scope.searchUser = res.current;
			$scope.specialties = res.specialties;
			$scope.offset = res.offset;
			pages= Math.ceil(res.count/10);
			$scope.total  = pages-1;
			for(var i=1;i<=pages;i++){
				numbers.push(i);
			}
			$scope.numbers = numbers;
			$(".weekcal").weekCalendar('refresh');
		});
	};
	$scope.paginate = function(offset){
		$scope.offset = offset;
		$scope.event.offset = $scope.offset;
		SearchService.getInfo($scope.event,function(res) {
			numbers = [];
			$scope.searchUser = res.current;
			$scope.questions = res.question;
			$scope.offset = res.offset;
			pages= Math.ceil(res.count/10);
			$scope.total  = pages-1;
			for(var i=1;i<=pages;i++){
				numbers.push(i);
			}
			$scope.numbers = numbers;
			$(".weekcal").weekCalendar('refresh');
		});
	};
	$scope.userId = function(data){
		$scope.EventUser = data;
		$('#client-eventModal').removeData('modal');
		$('#client-eventModal').modal('show');
	};
	$scope.ClientAppointment = function(data){
		if(data.description==null || data.description == ''){
			data.description = 'N/A';
		}
		data.professionnel = $scope.EventUser.user.id;
		$('body').addClass('disable-page');
		ClientEventService.postAppointment(data,function(res) {
			$('body').removeClass('disable-page');
			if(!res.event_restrict.status){
				$('#client-eventModal').modal('hide');
                                     	AlertService.error('You are Restrict to Create Appointment');
                                     	$scope.clientEvent.description = null;
                                     	$scope.clientEvent.start = null;
                                     	$scope.clientEvent.time = null;
                               }else if(!res.today.status){
				$('#client-eventModal').modal('hide');
                                     	AlertService.error("Vous avez déjà pris un rendez-vous avec ce professionnel aujourd'hui. Merci de prendre rendez-vous à une autre date");
                                     	$scope.clientEvent.description = null;
                                     	$scope.clientEvent.start = null;
                                     	$scope.clientEvent.time = null;
                               }else if(!res.limit.status){
				$('#client-eventModal').modal('hide');
                                     	AlertService.error("Désolé mais cet emplacement horaire n'est plus disponible. Merci d'en sélectionner un autre");
                                     	$scope.clientEvent.description = null;
                                     	$scope.clientEvent.start = null;
                                     	$scope.clientEvent.time = null;
                               }else if(!res.__all__.status){
				AlertService.error('Veuillez entrer les éléments correctement');
			}else if(res.__all__.status){
				$('#client-eventModal').modal('hide');
				AlertService.success(res.__all__.message);
				$scope.clientEvent.description = null;
                                     	$scope.clientEvent.start = null;
                                     	$scope.clientEvent.time = null;
			}
		});
	};
	$scope.timefunction = function(start,end){
		options = [];
		start_time = parseFloat(start);
		end_time = parseFloat(end);
		for(var i = start_time; i < end_time; i+=0.15) {
			time = i.toFixed(2);
			min = (time%1).toFixed(2);
			if(min == 0.60) {
				i+= 0.40;
				val = i.toFixed(2);
				if(parseFloat(val) < 10){
					op = float2int(val)+":"+val.split(".")[1];
					options.push({value:'0'+val,text:op});
				}else{
					op = float2int(val)+":"+val.split(".")[1];
					options.push({value:val,text:op});
				}
				continue;
			};
			if(parseFloat(time) < 10){
				op = float2int(time)+":"+time.split(".")[1];
				options.push({value:'0'+time,text:op});
			}else{
				op = float2int(time)+":"+time.split(".")[1];
				options.push({value:time,text:op});
			}
		}
		options.pop();
		return options;
           };
           float2int = function(value) {
		return value | 0;
	};
           $scope.professionConfig = {
		valueField: 'id',
		labelField: 'name',
		sort: false,
		sortField: [],
		maxItems: 1,	
	};
	$scope.specialtyConfig = {
		valueField: 'id',
		labelField: 'name',
		sort: false,
		sortField: [],
		maxItems: 1,	
	};
	$scope.notavailable = function(element,$compile){
		var check = moment(element.attr('data-date')).format('YYYY-MM-DD');
		var today = moment(new Date()).format('YYYY-MM-DD');
		id = element.attr("data-value");
		var currentUser = {};
		var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
		if(check >= today){
			angular.forEach($scope.searchUser,function(value,key){
				if(value.user.id == id){
					currentUser = value;
				}
			});
			angular.forEach(currentUser.schedule,function(value,key){
				date = new Date(check);
				day = date.getDay();
				var range = '';
				if(!($.isEmptyObject(currentUser.offline))  && currentUser.offline.status){
					var st_date = moment(currentUser.offline.start_date,"YYYY-MM-DD");
					var end_date = moment(currentUser.offline.end_date,"YYYY-MM-DD");
					range = moment.range(st_date,end_date);
				}
				var object = moment(check);
				if(!($.isEmptyObject(currentUser.offline)) && currentUser.offline.status && object.within(range)){
					element.html(' ');
					element.html("<span>N/A</span>");
					element.addClass('notavailable');
					element.removeClass('available');
				}else if(weekday[day] === value.day && value.status == true){
					element.html(' ');
					html = '<ul class="time-ul">';
					start_time = moment(value.start_time,"HH:mm:ss").format('HH.mm');
					end_time = moment(value.end_time,"HH:mm:ss").format('HH.mm');
					var i = 0;
					angular.forEach($scope.timefunction(start_time,end_time),function(value,index){
						ele = $scope.removeTimes1(currentUser,check,value.value);
						if(!ele[0]){
							i++;
							html+="<li ng-click='eventTime($event)' class='time-class' data-start='"+value.value+"'>"+value.text+"</li>";
						}
					});
					html+="</ul>";
					if(i > 8){
						html+= "<a ng-click='showmore($event)' class='show-more'>Voir plus</a><a ng-click='showless($event)' class='show-less'>Voir moins</a>";
					}
					html = $compile(html)($scope);
					element.html(html);
					element.removeClass('notavailable');
					element.addClass('available');
				}else if(weekday[day] === value.day && value.status == false){
					element.html(' ');
					html = $compile("<span>N/A</span>")($scope);
					element.html(html);
					element.addClass('notavailable');
					element.removeClass('available');
				}
			});
		}else{
			element.html("<span>N/A</span>");
			element.addClass('notavailable');
			element.removeClass('available');
		}
          };
          $scope.htmlstring = function($compile){
          		$(".wc-container .wc-header .wc-day-column-header").each(function(index){
          			en = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
          			fr = ['janv','févr','mars','avr', 'mai', 'juin', 'juil','août','sept','oct','nov','déc']; // naveen
                     	shortMonths = [];
                     	for(var i=0; i < en.length; i++) {
                     		shortMonths[en[i]] = fr[i];
                     	}
                     	value = $(this).html();
                     	value = value.split(' ');
                     	html = '';
                     	html = value[0] +' '+ shortMonths[value[1]] +' '+ value[2];
                     	$(this).html(' ');
                     	$(this).html(html);
                     });
          	};
          	$scope.spots = function($compile){
          		day1 = $(".wc-day-column-header.wc-day-1").html();
		for(var i = 0;i<7;i++){
			$(".slot-list li").each(function(index){
				if($(this).attr('data-index')==i){
					$(this).attr('data-date',moment(day1).add(i,'days').format("L"));
					$scope.notavailable($(this),$compile);
				}
			});
		}
		$scope.htmlstring($compile);
	};
          	$scope.showmore = function($event){
          		angular.element($event.target).hide();
		angular.element($event.target).parent().find(".time-ul > li:nth-child(n+9)").addClass('display-block');
          		angular.element($event.target).next().show();
          	};
          	$scope.showless = function($event){
          		angular.element($event.target).hide();
          		angular.element($event.target).parent().find(".time-ul > li:nth-child(n+9)").removeClass('display-block');
          		angular.element($event.target).prev().show();
          	};
          	$scope.eventTime = function($event){
          		var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
          		var time = angular.element($event.target).attr('data-start');
          		element = angular.element($event.target).parent().parent();
          		var check = moment(element.attr('data-date'),'MM/DD/YYYY').format('YYYY-MM-DD');
          		var today = moment(new Date()).format('YYYY-MM-DD');
          		if(check >= today){
          			user_id = element.attr('data-value');
          			angular.forEach($scope.searchUser,function(value,index){
          				if(value.user_id == user_id){
          					$scope.EventUser = value;
          					$("#dateoption").val(moment(check,'YYYY-MM-DD').format('DD/MM/YYYY'));
					$scope.clientEvent.start = moment(check,'YYYY-MM-DD').format('DD/MM/YYYY');
					$scope.clientEvent.time = time;
          					angular.forEach($scope.EventUser.schedule,function(value,key){
          						date = new Date(check);
          						day = date.getDay();
          						if(weekday[day] === value.day && value.status == true){
          							start_time = moment(value.start_time,"HH:mm:ss").format('HH.mm');
					 		end_time = moment(value.end_time,"HH:mm:ss").format('HH.mm');
					 		options = $scope.timefunction(start_time,end_time);
					 		selectize = $("#timeoption").selectize(options)[0].selectize;
					 		angular.forEach(options,function(value){
					 			ele = $scope.removeTimes(check,value.value);
					 			if(!ele[0]){
					 				selectize.addOption(value);
					 			}
					 		});
					 		$timeout(function() {
					 			 selectize.setValue(time);
					 		},300);
          							$('#client-eventModal').modal();
	          					}
	          				});
          				}
          			});
          		}
          	};
          	$scope.removeTimes1 = function(user,start,time){
                     return $.grep(user.daytimes,function(n,i){
                               return n.start == start && n.time == time;
                     });
           };
	function initialize(){
		var mapProp={
			center:new google.maps.LatLng(48.856614,2.3522219000000177),
			zoom:10,
			mapTypeId:google.maps.MapTypeId.ROADMAP
		};
		var map=new google.maps.Map(document.getElementById("googleMap"), mapProp);
	}
          var markersArray = [];
          function plotPoint(lat,lon,title,popUpContent,markerIcon){
          		var marker = new google.maps.Marker({
                     	position: new google.maps.LatLng(lat,lon),
                     	map: map,
	                     title:title,
          	          		icon: markerIcon
                	});
                	markersArray.push(marker);
                	var infowindow = new google.maps.InfoWindow({
                     	content: popUpContent
                	});
                	google.maps.event.addListener(marker,'click', function() {
                     	infowindow.open(map,marker);
                	});
           }
           var map=new google.maps.Map(document.getElementById("googleMap"),{
           	center:new google.maps.LatLng(48.8567,2.3508),
           	zoom:5,
           	mapTypeId:google.maps.MapTypeId.ROADMAP,
           });
           google.maps.event.addDomListener(window,'load',initialize);
           $scope.$watch('searchUser',function() {
           	$.each(markersArray,function(index,value){
           		markersArray[index].setMap(null);
           	});
           	if($scope.searchUser.length > 0){
           		$.each($scope.searchUser,function(index,value){
           			var image = '<div class="col-md-4 no-padd">';
                     		image+='<img src="'+$scope.userImage+'/'+value.image+'" width="72" height="90"></div>';
                     		var text = image+'<div class="col-md-8 map-bold"><b>'+value.user.first_name+'</b><br>'+value.user.address+'<br>'+value.user.city+'-'+value.user.zipcode+'</div>';
                     		plotPoint(value.user.latitude,value.user.longitude,value.user.first_name,text);
                     	});
                     	AutoCenter();
                     }
           });
           function AutoCenter() {
           	var bounds = new google.maps.LatLngBounds();
           	$.each(markersArray, function (index,marker) {
                     	bounds.extend(marker.position);
                	});
                	map.fitBounds(bounds);
           }
}]);